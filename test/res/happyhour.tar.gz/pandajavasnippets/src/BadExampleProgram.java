//A Very Simple Example that does not compile
class BadExampleProgram {
  public static void main(String[] args) {
    System.out.println("I'm a Simple Program")
  }
}