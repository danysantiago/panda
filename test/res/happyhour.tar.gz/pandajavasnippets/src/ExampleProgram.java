//A Very Simple Example
class ExampleProgram {
  public static void main(String[] args) {
    System.out.println("I'm a Simple Program");
  }
}